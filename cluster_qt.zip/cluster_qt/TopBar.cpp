#include "includes/TopBar.h"

TopBar::TopBar() { }

TopBar::TopBar(QWidget* parent) : QWidget(parent) { }

TopBar::~TopBar() {}
